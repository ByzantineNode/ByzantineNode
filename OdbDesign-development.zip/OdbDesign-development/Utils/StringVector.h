#pragma once

#include <vector>
#include <string>

namespace Utils
{
	typedef std::vector<std::string> StringVector;
}
