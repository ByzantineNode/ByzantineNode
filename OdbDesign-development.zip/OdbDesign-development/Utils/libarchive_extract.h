#pragma once

namespace Utils
{
	bool extract(const char* filename, const char* destDir);
}
