#pragma once

namespace Odb::Lib::FileModel
{
	class OdbFileRecord
	{
	};
}
