// extractMatrixFileData.cpp
#include "extractStepData.h" // (or whichever header declares extractMatrixFileData)
#include "StepDirectory.h"
#include "extractMatrixFileData.h"       // if needed
#include "extractLayerData.h"            // if needed
#include "extractNetlistData.h"          // if needed
#include "extractEdaData.h"              // if needed
#include "extractAttrListFileFromStep.h" // if needed
#include "extractProfileFileFromStep.h"  // if needed
#include "extractStepHdrFile.h"          // if needed
#include <iostream>

namespace Odb::Lib::FileModel::Design
{
    void extractMatrixFileData(const FileArchive &archive)
    {
        // Retrieve the matrix file from the archive using its getter.
        const MatrixFile &matrixFile = archive.GetMatrixFile();

        // --- Print Step Records ---
        std::cout << "\n[Matrix File] Step Records:" << std::endl;
        const auto &stepRecords = matrixFile.GetStepRecords();
        std::cout << "Number of Step Records: " << stepRecords.size() << std::endl;
        for (size_t i = 0; i < stepRecords.size(); ++i)
        {
            const auto &step = stepRecords[i];
            std::cout << "Step Record " << i << ":" << std::endl;
            std::cout << "  Column: " << step->column << std::endl;
            std::cout << "  Name: " << step->name << std::endl;
            std::cout << "  ID: " << step->id << std::endl;
        }

        // --- Print Layer Records ---
        std::cout << "\n[Matrix File] Layer Records:" << std::endl;
        const auto &layerRecords = matrixFile.GetLayerRecords();
        std::cout << "Number of Layer Records: " << layerRecords.size() << std::endl;
        for (size_t i = 0; i < layerRecords.size(); ++i)
        {
            const auto &layer = layerRecords[i];
            std::cout << "Layer Record " << i << ":" << std::endl;
            std::cout << "  Row: " << layer->row << std::endl;
            std::cout << "  Name: " << layer->name << std::endl;
            std::cout << "  ID: " << layer->id << std::endl;
            // Print enums as integers; you can convert these to strings if needed.
            std::cout << "  Context: " << static_cast<int>(layer->context) << std::endl;
            std::cout << "  Type: " << static_cast<int>(layer->type) << std::endl;
            std::cout << "  Polarity: " << static_cast<int>(layer->polarity) << std::endl;
            std::cout << "  Dielectric Type: " << static_cast<int>(layer->dielectricType) << std::endl;
            std::cout << "  Dielectric Name: " << layer->dielectricName << std::endl;
            std::cout << "  Form: " << static_cast<int>(layer->form) << std::endl;
            std::cout << "  CU Top: " << layer->cuTop << std::endl;
            std::cout << "  CU Bottom: " << layer->cuBottom << std::endl;
            std::cout << "  Ref: " << layer->ref << std::endl;
            std::cout << "  Start Name: " << layer->startName << std::endl;
            std::cout << "  End Name: " << layer->endName << std::endl;
            std::cout << "  Old Name: " << layer->oldName << std::endl;
            std::cout << "  Add Type: " << layer->addType << std::endl;
            std::cout << "  Color: " << layer->color.to_string() << std::endl;
        }
    }
} // namespace Odb::Lib::FileModel::Design
