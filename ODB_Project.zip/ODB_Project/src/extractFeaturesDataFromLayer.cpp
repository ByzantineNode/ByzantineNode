// extractFeaturesData.cpp
#include "extractFeaturesData.h"
#include "FeaturesFile.h"
#include <iostream>
#include <string>
#include <enums.h>

namespace Odb::Lib::FileModel::Design
{

    void extractFeaturesDataFromLayer(const std::shared_ptr<LayerDirectory> &layer)
    {
        std::cout << "\n  [Features Data] for Layer: " << layer->GetName() << std::endl;
        FeaturesFile currFeaturesFile = layer->GetFeaturesFile();

        if (currFeaturesFile.GetId() == 0)
        {
            std::cout << "    No Features File found in this layer." << std::endl;
        }
        else
        {
            std::cout << "    Feature ID: " << currFeaturesFile.GetId() << std::endl;
            std::cout << "    Units: " << currFeaturesFile.GetUnits() << std::endl;
            std::cout << "    Features File Path: " << currFeaturesFile.GetPath() << std::endl;
            std::cout << "    Feature Directory: " << currFeaturesFile.GetDirectory() << std::endl;

            // Print symbol names
            const auto &symbolNames = currFeaturesFile.GetSymbolNamesByName();
            std::cout << "    Symbols in the file: " << symbolNames.size() << std::endl;
            for (const auto &[symbolName, symbolPtr] : symbolNames)
            {
                std::cout << "      Symbol Name: " << symbolName << std::endl;
                std::cout << "      Unit Type: "
                          << (symbolPtr->GetUnitType() == UnitType::Metric ? "Metric" : "Imperial")
                          << std::endl;
            }

            // Retrieve and print feature records
            const auto &featureRecords = currFeaturesFile.GetFeatureRecords();
            std::cout << "    Features in the file: " << featureRecords.size() << std::endl;
            for (const auto &featureRecord : featureRecords)
            {
                std::cout << "      -----------------------------" << std::endl;
                std::cout << "      Feature Record:" << std::endl;

                // Print feature type as string
                std::string typeStr;
                switch (featureRecord->type)
                {
                case FeaturesFile::FeatureRecord::Type::Line:
                    typeStr = "Line";
                    break;
                case FeaturesFile::FeatureRecord::Type::Pad:
                    typeStr = "Pad";
                    break;
                case FeaturesFile::FeatureRecord::Type::Text:
                    typeStr = "Text";
                    break;
                case FeaturesFile::FeatureRecord::Type::Arc:
                    typeStr = "Arc";
                    break;
                case FeaturesFile::FeatureRecord::Type::Surface:
                    typeStr = "Surface";
                    break;
                default:
                    typeStr = "Unknown";
                    break;
                }
                std::cout << "        Type: " << typeStr << std::endl;

                if (featureRecord->type == FeaturesFile::FeatureRecord::Type::Line)
                {
                    std::cout << "        Start: (" << featureRecord->xs << ", " << featureRecord->ys << ")" << std::endl;
                    std::cout << "        End: (" << featureRecord->xe << ", " << featureRecord->ye << ")" << std::endl;
                }
                else if (featureRecord->type == FeaturesFile::FeatureRecord::Type::Pad)
                {
                    std::cout << "        Position: (" << featureRecord->x << ", " << featureRecord->y << ")" << std::endl;
                    std::cout << "        Symbol Number: " << featureRecord->apt_def_symbol_num << std::endl;
                    if (featureRecord->apt_def_symbol_num == -1)
                        std::cout << "        Resize Factor: " << featureRecord->apt_def_resize_factor << std::endl;
                }
                else if (featureRecord->type == FeaturesFile::FeatureRecord::Type::Text)
                {
                    std::cout << "        Position: (" << featureRecord->x << ", " << featureRecord->y << ")" << std::endl;
                    std::cout << "        Font: " << featureRecord->font << std::endl;
                    std::cout << "        Size: (" << featureRecord->xsize << ", " << featureRecord->ysize << ")" << std::endl;
                    std::cout << "        Width Factor: " << featureRecord->width_factor << std::endl;
                    std::cout << "        Text: " << featureRecord->text << std::endl;
                    std::cout << "        Version: " << featureRecord->version << std::endl;
                }
                else if (featureRecord->type == FeaturesFile::FeatureRecord::Type::Arc)
                {
                    std::cout << "        Start: (" << featureRecord->xs << ", " << featureRecord->ys << ")" << std::endl;
                    std::cout << "        End: (" << featureRecord->xe << ", " << featureRecord->ye << ")" << std::endl;
                    std::cout << "        Center: (" << featureRecord->xc << ", " << featureRecord->yc << ")" << std::endl;
                    std::cout << "        Clockwise: " << (featureRecord->cw ? "Yes" : "No") << std::endl;
                }
                else if (featureRecord->type == FeaturesFile::FeatureRecord::Type::Surface)
                {
                    std::cout << "        Surface feature with " << featureRecord->GetContourPolygons().size() << " contour polygon(s)" << std::endl;
                }

                // Print common fields
                std::cout << "        Symbol Number: " << featureRecord->sym_num << std::endl;
                std::cout << "        Polarity: "
                          << (featureRecord->polarity == Polarity::Positive ? "Positive" : "Negative")
                          << std::endl;
                std::cout << "        DCode: " << featureRecord->dcode << std::endl;
                std::cout << "        ID: " << featureRecord->id << std::endl;
                std::cout << "        Orientation: " << featureRecord->orient_def << std::endl;
                if (featureRecord->orient_def == 8 || featureRecord->orient_def == 9)
                    std::cout << "        Orientation Rotation: " << featureRecord->orient_def_rotation << std::endl;

                // Print contour polygons
                const auto &contourPolygons = featureRecord->GetContourPolygons();
                if (!contourPolygons.empty())
                {
                    std::cout << "        Contour Polygons:" << std::endl;
                    int polygonIndex = 0;
                    for (const auto &polygon : contourPolygons)
                    {
                        std::cout << "          Polygon " << polygonIndex++ << ":" << std::endl;
                        std::cout << "            Start: (" << polygon->xStart << ", " << polygon->yStart << ")" << std::endl;
                        std::string polyType = (polygon->type == ContourPolygon::Type::Island ? "Island" : "Hole");
                        std::cout << "            Type: " << polyType << std::endl;

                        // Print polygon parts (arcs and segments)
                        if (!polygon->m_polygonParts.empty())
                        {
                            int partIndex = 0;
                            for (const auto &part : polygon->m_polygonParts)
                            {
                                std::cout << "              Part " << partIndex++ << ":" << std::endl;
                                if (part->type == ContourPolygon::PolygonPart::Type::Arc)
                                {
                                    std::cout << "                Type: Arc" << std::endl;
                                    std::cout << "                End: (" << part->endX << ", " << part->endY << ")" << std::endl;
                                    std::cout << "                Center: (" << part->xCenter << ", " << part->yCenter << ")" << std::endl;
                                    std::cout << "                Clockwise: " << (part->isClockwise ? "Yes" : "No") << std::endl;
                                }
                                else if (part->type == ContourPolygon::PolygonPart::Type::Segment)
                                {
                                    std::cout << "                Type: Segment" << std::endl;
                                    std::cout << "                End: (" << part->endX << ", " << part->endY << ")" << std::endl;
                                }
                            }
                        }

                        // Print attributes (if any)
                        /*if (!featureRecord->m_attributeLookupTable.empty())
                        {
                            std::cout << "        Attributes:" << std::endl;
                            for (const auto &attr : featureRecord->m_attributeLookupTable)
                            {
                                std::cout << "          " << attr.first << " = " << attr.second << std::endl;
                            }
                        }*/
                    }
                }
            }
        }
    }

} // namespace Odb::Lib::FileModel::Design
