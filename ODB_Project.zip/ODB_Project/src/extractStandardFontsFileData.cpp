// extractStandardFontsFileData.cpp
#include "extractStandardFontsFileData.h"
#include "StandardFontsFile.h"
#include <iostream>

namespace Odb::Lib::FileModel::Design
{

    void extractStandardFontsFileData(const FileArchive &archive)
    {
        const auto &standardFontsFile = archive.GetStandardFontsFile();

        // Extracting basic attributes
        std::cout << "X Size: " << standardFontsFile.GetXSize() << std::endl;
        std::cout << "Y Size: " << standardFontsFile.GetYSize() << std::endl;
        std::cout << "Offset: " << standardFontsFile.GetOffset() << std::endl;

        // Extracting Character Blocks
        const auto &characterBlocks = standardFontsFile.GetCharacterBlocks();
        std::cout << "Number of Character Blocks: " << characterBlocks.size() << std::endl;

        for (const auto &characterBlock : characterBlocks)
        {
            std::cout << "Character: " << characterBlock->character << std::endl;

            // Extracting Line Records
            const auto &lineRecords = characterBlock->m_lineRecords;
            std::cout << "  Number of Line Records: " << lineRecords.size() << std::endl;

            for (const auto &lineRecord : lineRecords)
            {
                std::cout << "    Line Start: (" << lineRecord->xStart << ", " << lineRecord->yStart << ")"
                          << " -> End: (" << lineRecord->xEnd << ", " << lineRecord->yEnd << ")" << std::endl;
                std::cout << "    Width: " << lineRecord->width << std::endl;
                std::cout << "    Polarity: " << (lineRecord->polarity == Polarity::Positive ? "Positive" : "Negative") << std::endl;
                std::cout << "    Shape: " << (lineRecord->shape == LineShape::Round ? "Round" : "Square") << std::endl;
            }
        }
    }

} // namespace Odb::Lib::FileModel::Design
