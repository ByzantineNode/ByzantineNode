#include "extractMiscInfoFileData.h"
#include "MiscInfoFile.h"
#include "FileArchive.h"
#include <iostream>
#include <iomanip>

namespace Odb::Lib::FileModel::Design
{

    void extractMiscInfoFileData(const FileArchive &archive)
    {
        const auto &miscInfoFile = archive.GetMiscInfoFile();

        std::cout << "\n====== [Misc Info File Data] ======\n";

        std::cout << "Product Model Name: " << miscInfoFile.GetProductModelName() << std::endl;
        std::cout << "Job Name: " << miscInfoFile.GetJobName() << std::endl;
        std::cout << "ODB Version Major: " << miscInfoFile.GetOdbVersionMajor() << std::endl;
        std::cout << "ODB Version Minor: " << miscInfoFile.GetOdbVersionMinor() << std::endl;
        std::cout << "ODB Source: " << miscInfoFile.GetOdbSource() << std::endl;

        // Convert `system_clock::time_point` to readable timestamp
        auto formatTime = [](std::chrono::system_clock::time_point time) -> std::string
        {
            std::time_t t = std::chrono::system_clock::to_time_t(time);
            std::stringstream ss;
            ss << std::put_time(std::localtime(&t), "%Y-%m-%d %H:%M:%S");
            return ss.str();
        };

        std::cout << "Creation Date: " << formatTime(miscInfoFile.GetCreationDate()) << std::endl;
        std::cout << "Save Date: " << formatTime(miscInfoFile.GetSaveDate()) << std::endl;
        std::cout << "Save Application: " << miscInfoFile.GetSaveApp() << std::endl;
        std::cout << "Save User: " << miscInfoFile.GetSaveUser() << std::endl;
        std::cout << "Units: " << miscInfoFile.GetUnits() << std::endl;
        std::cout << "Max Unique ID: " << miscInfoFile.GetMaxUniqueId() << std::endl;

        std::cout << "===================================\n";
    }

} // namespace Odb::Lib::FileModel::Design
