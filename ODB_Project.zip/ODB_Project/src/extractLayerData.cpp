// extractLayerData.cpp
#include "extractLayerData.h"
#include "LayerDirectory.h"       // For layer pointer and its methods
#include "extractComponentData.h" // Function that processes component data on a single layer
#include "extractFeaturesData.h"  // Function that processes feature data on a single layer
#include "extractAttributeData.h"
#include <iostream>
#include <enums.h>
namespace Odb::Lib::FileModel::Design
{

    void extractLayerData(const std::shared_ptr<StepDirectory> &step)
    {
        const auto &layers = step->GetLayersByName();
        std::cout << "Layers in the step: " << layers.size() << std::endl;
        for (const auto &[layerName, layerPtr] : layers)
        {
            std::cout << "\n  Layer Name: " << layerPtr->GetName() << std::endl;
            std::cout << "  Layer Path: " << layerPtr->GetPath() << std::endl;

            // Call component extraction on this layer
            extractComponentDataFromLayer(layerPtr);
            // Call feature extraction on this layer
            extractFeaturesDataFromLayer(layerPtr);
            // Call attribute extraction on this layer
            extractAttributeDataFromLayer(layerPtr);
        }
    }

} // namespace Odb::Lib::FileModel::Design
