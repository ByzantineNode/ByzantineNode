#include "extractMiscAttrListFile.h"
#include "AttrListFile.h"
#include "FileArchive.h"
#include <iostream>

namespace Odb::Lib::FileModel::Design
{

    void extractMiscAttrListFile(const FileArchive &archive)
    {
        const auto &miscAttrListFile = archive.GetMiscAttrListFile();

        std::cout << "\n====== [Misc Attribute List File Data] ======\n";

        // Extracting and printing units
        std::cout << "Units: " << miscAttrListFile.GetUnits() << std::endl;

        // Extracting and printing attributes
        const auto &attributes = miscAttrListFile.GetAttributes();
        if (attributes.empty())
        {
            std::cout << "No attributes found in Misc Attr List File." << std::endl;
        }
        else
        {
            std::cout << "Attributes: " << std::endl;
            for (const auto &[key, value] : attributes)
            {
                std::cout << "  - " << key << " = " << value << std::endl;
            }
        }

        std::cout << "=============================================\n";
    }

} // namespace Odb::Lib::FileModel::Design
