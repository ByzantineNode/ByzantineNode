// extractStepData.cpp
#include "extractStepData.h"
#include "StepDirectory.h"
#include "extractLayerData.h"
#include "extractNetlistData.h"
#include "extractEdaData.h"
#include "extractAttrListFileFromStep.h"
#include "extractProfileFileFromStep.h"
#include "extractStepHdrFile.h"
#include <iostream>

namespace Odb::Lib::FileModel::Design
{

    void extractStepData(const FileArchive &archive)
    {
        const auto &steps = archive.GetStepsByName();
        std::cout << "Steps in the archive: " << steps.size() << std::endl;
        for (const auto &[stepName, stepPtr] : steps)
        {
            std::cout << "\nStep Name: " << stepName << std::endl;
            extractLayerData(stepPtr);
            extractNetListData(stepPtr);
            extractEddaDData(stepPtr);
            extractAttrListFileFromStep(stepPtr);
            extractProfileFileFromStep(stepPtr);
            extractStepHdrFileData(stepPtr);
        }
    }

} // namespace Odb::Lib::FileModel::Design
