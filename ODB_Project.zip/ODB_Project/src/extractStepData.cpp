// extractStepData.cpp
#include "extractStepData.h"
#include "StepDirectory.h"    // For StepDirectory and its GetLayersByName()
#include "extractLayerData.h" // Our next level extraction
#include "extractNetlistData.h"
#include "extractEdaData.h"
#include <iostream>

namespace Odb::Lib::FileModel::Design
{

    void extractStepData(const FileArchive &archive)
    {
        const auto &steps = archive.GetStepsByName();
        std::cout << "Steps in the archive: " << steps.size() << std::endl;
        for (const auto &[stepName, stepPtr] : steps)
        {
            std::cout << "\nStep Name: " << stepName << std::endl;
            // For each step, process its layers.
            extractLayerData(stepPtr);
            extractNetListData(stepPtr);
            extractEddaDData(stepPtr);
        }
    }

} // namespace Odb::Lib::FileModel::Design
