// extractMatrixFileData.cpp
#include "extractMiscAttrListFile.h"
#include "MiscInfoFile.h"
#include "FileArchive.h"
#include <iostream>

namespace Odb::Lib::FileModel::Design
{

    void extractMiscAttrListFile(const FileArchive &archive)
    {
        const auto &steps = archive.GetMiscAttrListFile();
    }

} // namespace Odb::Lib::FileModel::Design

const AttrListFile &FileArchive::GetMiscAttrListFile() const
{
    return m_miscAttrListFile;
}

AttrListFile m_miscAttrListFile;