#include "StepDirectory.h"
#include <iostream>
#include <enums.h>
#include "extractEdaData.h"

namespace Odb::Lib::FileModel::Design
{

    void extractEddaDData(const std::shared_ptr<StepDirectory> &step)
    {
        // Retrieve the EDA data file from StepDirectory.
        const auto &CurrEdaDataFile = step->GetEdaDataFile();

        if (!CurrEdaDataFile.GetPath().empty())
        {
            std::cout << "////////////EDA Data File/////////////" << std::endl;
            std::cout << "Path: " << CurrEdaDataFile.GetPath() << std::endl;
            std::cout << "Directory: " << CurrEdaDataFile.GetDirectory() << std::endl;
            std::cout << "Units: " << CurrEdaDataFile.GetUnits() << std::endl;
            std::cout << "Source: " << CurrEdaDataFile.GetSource() << std::endl;

            // Print layer names.
            std::cout << "\nLayer Names:" << std::endl;
            for (const auto &layer : CurrEdaDataFile.GetLayerNames())
            {
                std::cout << " - " << layer << std::endl;
            }

            // Print attribute names.
            std::cout << "\nAttribute Names:" << std::endl;
            for (const auto &attr : CurrEdaDataFile.GetAttributeNames())
            {
                std::cout << " - " << attr << std::endl;
            }

            // Print attribute text values.
            std::cout << "\nAttribute Text Values:" << std::endl;
            for (const auto &attrText : CurrEdaDataFile.GetAttributeTextValues())
            {
                std::cout << " - " << attrText << std::endl;
            }

            // Print net records.
            std::cout << "\nNet Records:" << std::endl;
            for (const auto &net : CurrEdaDataFile.GetNetRecords())
            {
                std::cout << "Net Name: " << net->name
                          << ", Index: " << net->index << std::endl;

                // Iterate through subnet records.
                for (const auto &subnet : net->m_subnetRecords)
                {
                    std::cout << "\tSubnet (Index: " << subnet->index << "): ";
                    switch (subnet->type)
                    {
                    case EdaDataFile::NetRecord::SubnetRecord::Type::Via:
                        std::cout << "Via";
                        break;
                    case EdaDataFile::NetRecord::SubnetRecord::Type::Trace:
                        std::cout << "Trace";
                        break;
                    case EdaDataFile::NetRecord::SubnetRecord::Type::Plane:
                        std::cout << "Plane";
                        break;
                    case EdaDataFile::NetRecord::SubnetRecord::Type::Toeprint:
                        std::cout << "Toeprint";
                        break;
                    default:
                        std::cout << "Unknown";
                        break;
                    }
                    std::cout << std::endl;

                    // Print each feature ID record in the subnet.
                    for (const auto &fid : subnet->m_featureIdRecords)
                    {
                        std::cout << "\t\tFeatureIdRecord: ";
                        switch (fid->type)
                        {
                        case EdaDataFile::FeatureIdRecord::Type::Copper:
                            std::cout << "Copper";
                            break;
                        case EdaDataFile::FeatureIdRecord::Type::Laminate:
                            std::cout << "Laminate";
                            break;
                        case EdaDataFile::FeatureIdRecord::Type::Hole:
                            std::cout << "Hole";
                            break;
                        default:
                            std::cout << "Unknown";
                            break;
                        }
                        std::cout << ", LayerNumber: " << fid->layerNumber << ", FeatureNumber: " << fid->featureNumber << std::endl;
                    }
                }

                // Print any property records attached to the net.
                for (const auto &prop : net->m_propertyRecords)
                {
                    std::cout << "Property Record - Name: " << prop->name << ", Value: " << prop->value << std::endl;

                    if (!prop->floatValues.empty())
                    {
                        std::cout << ", Float Values: ";
                        for (const auto &f : prop->floatValues)
                        {
                            std::cout << f << " ";
                        }
                    }

                    std::cout << std::endl;
                }
            }

            // Print package records.
            std::cout << "\nPackage Records:" << std::endl;
            for (const auto &pkg : CurrEdaDataFile.GetPackageRecords())
            {
                std::cout << "Package Name: " << pkg->name << ", Pitch: " << pkg->pitch << ", Bounds: (" << pkg->xMin << ", " << pkg->yMin << ") to (" << pkg->xMax << ", " << pkg->yMax << ")" << std::endl;

                // Print outline records.
                for (const auto &outline : pkg->m_outlineRecords)
                {
                    std::cout << "\tOutline Record: ";
                    switch (outline->type)
                    {
                    case EdaDataFile::PackageRecord::OutlineRecord::Type::Rectangle:
                        std::cout << "Rectangle, LowerLeft: (" << outline->lowerLeftX << ", " << outline->lowerLeftY << "), Width: " << outline->width << ", Height: " << outline->height;
                        break;
                    case EdaDataFile::PackageRecord::OutlineRecord::Type::Circle:
                        std::cout << "Circle, Center: (" << outline->xCenter << ", " << outline->yCenter << "), Radius: " << outline->radius;
                        break;
                    case EdaDataFile::PackageRecord::OutlineRecord::Type::Square:
                        std::cout << "Square, Center: (" << outline->xCenter << ", " << outline->yCenter << "), HalfSide: " << outline->halfSide;
                        break;
                    case EdaDataFile::PackageRecord::OutlineRecord::Type::Contour:
                        std::cout << "Contour";
                        break;
                    default:
                        std::cout << "Unknown Outline";
                        break;
                    }
                    std::cout << std::endl;
                }

                // Print pin records.
                for (const auto &pin : pkg->m_pinRecords)
                {
                    std::cout << "\tPin Record: Name: " << pin->name << ", Type: ";
                    switch (pin->type)
                    {
                    case EdaDataFile::PackageRecord::PinRecord::Type::ThroughHole:
                        std::cout << "ThroughHole";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::Type::Blind:
                        std::cout << "Blind";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::Type::Surface:
                        std::cout << "Surface";
                        break;
                    default:
                        std::cout << "Unknown";
                        break;
                    }
                    std::cout << ", Center: (" << pin->xCenter << ", " << pin->yCenter << ")" << ", FinishedHoleSize: " << pin->finishedHoleSize;
                    std::cout << ", ElectricalType: ";
                    switch (pin->electricalType)
                    {
                    case EdaDataFile::PackageRecord::PinRecord::ElectricalType::Electrical:
                        std::cout << "Electrical";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::ElectricalType::NonElectrical:
                        std::cout << "NonElectrical";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::ElectricalType::Undefined:
                        std::cout << "Undefined";
                        break;
                    default:
                        std::cout << "Unknown";
                        break;
                    }
                    std::cout << ", MountType: ";
                    switch (pin->mountType)
                    {
                    case EdaDataFile::PackageRecord::PinRecord::MountType::Smt:
                        std::cout << "Smt";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::MountType::RecommendedSmtPad:
                        std::cout << "RecommendedSmtPad";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::MountType::MT_ThroughHole:
                        std::cout << "MT_ThroughHole";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::MountType::RecommendedThroughHole:
                        std::cout << "RecommendedThroughHole";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::MountType::Pressfit:
                        std::cout << "Pressfit";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::MountType::NonBoard:
                        std::cout << "NonBoard";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::MountType::Hole:
                        std::cout << "Hole";
                        break;
                    case EdaDataFile::PackageRecord::PinRecord::MountType::MT_Undefined:
                        std::cout << "MT_Undefined";
                        break;
                    default:
                        std::cout << "Unknown";
                        break;
                    }
                    std::cout << ", ID: " << pin->id << ", Index: " << pin->index << std::endl;

                    // If the pin has its own outline records, print them.
                    for (const auto &pOutline : pin->m_outlineRecords)
                    {
                        std::cout << "\t\tPin Outline Record: ";
                        switch (pOutline->type)
                        {
                        case EdaDataFile::PackageRecord::OutlineRecord::Type::Rectangle:
                            std::cout << "Rectangle";
                            break;
                        case EdaDataFile::PackageRecord::OutlineRecord::Type::Circle:
                            std::cout << "Circle";
                            break;
                        case EdaDataFile::PackageRecord::OutlineRecord::Type::Square:
                            std::cout << "Square";
                            break;
                        case EdaDataFile::PackageRecord::OutlineRecord::Type::Contour:
                            std::cout << "Contour";
                            break;
                        default:
                            std::cout << "Unknown";
                            break;
                        }
                        std::cout << std::endl;
                    }
                }

                // Print package-level property records.
                for (const auto &prop : pkg->m_propertyRecords)
                {
                    std::cout << "Property Record - Name: " << prop->name << ", Value: " << prop->value << std::endl;

                    if (!prop->floatValues.empty())
                    {
                        std::cout << ", Float Values: ";
                        for (const auto &f : prop->floatValues)
                        {
                            std::cout << f << " ";
                        }
                    }

                    std::cout << std::endl;
                }
            }

            // Print feature group records.
            std::cout << "\nFeature Group Records:" << std::endl;
            for (const auto &fg : CurrEdaDataFile.GetFeatureGroupRecords())
            {
                std::cout << "Feature Group Type: " << fg->type << std::endl;
                // Feature group property records.
                for (const auto &prop : fg->m_propertyRecords)
                {
                    std::cout << "Property Record - Name: " << prop->name << ", Value: " << prop->value << std::endl;

                    if (!prop->floatValues.empty())
                    {
                        std::cout << ", Float Values: ";
                        for (const auto &f : prop->floatValues)
                        {
                            std::cout << f << " ";
                        }
                    }

                    std::cout << std::endl;
                }
                // Feature id records in the feature group.
                for (const auto &fid : fg->m_featureIdRecords)
                {
                    std::cout << "\tFeatureIdRecord: ";
                    switch (fid->type)
                    {
                    case EdaDataFile::FeatureIdRecord::Type::Copper:
                        std::cout << "Copper";
                        break;
                    case EdaDataFile::FeatureIdRecord::Type::Laminate:
                        std::cout << "Laminate";
                        break;
                    case EdaDataFile::FeatureIdRecord::Type::Hole:
                        std::cout << "Hole";
                        break;
                    default:
                        std::cout << "Unknown";
                        break;
                    }
                    std::cout << ", LayerNumber: " << fid->layerNumber << ", FeatureNumber: " << fid->featureNumber << std::endl;
                }
            }

            // Print top–level property records.
            std::cout << "\nTop-level Property Records:" << std::endl;
            for (const auto &prop : CurrEdaDataFile.GetPropertyRecords())
            {
                std::cout << "Property Record - Name: " << prop->name << ", Value: " << prop->value << std::endl;

                if (!prop->floatValues.empty())
                {
                    std::cout << ", Float Values: ";
                    for (const auto &f : prop->floatValues)
                    {
                        std::cout << f << " ";
                    }
                }

                std::cout << std::endl;
            }

            std::cout << "=====================================" << std::endl;
        }
        else
        {
            std::cout << "EDA Data File is empty or not loaded." << std::endl;
        }
    }

}
