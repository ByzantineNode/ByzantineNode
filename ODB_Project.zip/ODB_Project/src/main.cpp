#include "FileArchive.h"
#include "extractStepData.h"
#include "extractMatrixFileData.h"
#include "extractStandardFontsFileData.h"
#include "extractSymbolsDirectoriesData.h"
#include "extractMiscInfoFileData.h"
#include "extractMiscAttrListFile.h"
#include <iostream>
#include <string>
#include <enums.h>

int main()
{
    std::string archiveName = "/home/ritik/test/designodb_rigidflex.tgz";
    Odb::Lib::FileModel::Design::FileArchive archive(archiveName);

    // Parsing the file model
    bool status = archive.ParseFileModel();
    if (status)
    {
        std::cout << "File Model Parsed Successfully" << std::endl;
        std::cout << "Extracted Product Name: " << archive.GetProductName() << std::endl;
        extractStepData(archive);
        extractMatrixFileData(archive);
        extractStandardFontsFileData(archive);
        extractSymbolsDirectoriesData(archive);
        extractMiscInfoFileData(archive);
        extractMiscAttrListFile(archive);
    }
    else
    {
        std::cout << "File Model Parsing Failed" << std::endl;
        return -1;
    }

    return 0;
}
