#include "FileArchive.h"
#include "extractStepData.h"
#include <iostream>
#include <string>
#include <enums.h>

int main()
{
    std::string archiveName = "/home/ritik/test/designodb_rigidflex.tgz";
    Odb::Lib::FileModel::Design::FileArchive archive(archiveName);

    // Parse the file model
    bool status = archive.ParseFileModel();
    if (status)
    {
        std::cout << "File Model Parsed Successfully" << std::endl;
        Odb::Lib::FileModel::Design::extractStepData(archive);
    }
    else
    {
        std::cout << "File Model Parsing Failed" << std::endl;
        return -1;
    }

    return 0;
}
