// extractComponentData.cpp
#include "extractAttributeData.h"
#include "AttrListFile.h"
#include <iostream>
#include <enums.h>

namespace Odb::Lib::FileModel::Design
{

    void extractAttributeDataFromLayer(const std::shared_ptr<LayerDirectory> &layer)
    {
        std::cout << "\n  [Component Data] for Layer: " << layer->GetName() << std::endl;
        // Access the ComponentsFile from the layer.
        AttrListFile currAttrListFile = layer->GetAttrListFile();
        if (!currAttrListFile.GetAttributes().empty())
        {
            std::cout << "    Units: " << currAttrListFile.GetUnits() << std::endl;
            AttrListFile::AttributeMap attrMap = currAttrListFile.GetAttributes();
            for (auto &attr : attrMap)
            {
                std::cout << "    Attribute Name: " << attr.first << std::endl;
                std::cout << "    Attribute Value: " << attr.second << std::endl;
            }
        }
        else
        {
            std::cout << "    No Attributes found in the file" << std::endl;
        }
    }

} // namespace Odb::Lib::FileModel::Design
