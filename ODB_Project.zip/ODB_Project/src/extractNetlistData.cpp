#include "extractNetlistData.h"
#include "NetlistFile.h"
#include <iostream>

namespace Odb::Lib::FileModel::Design
{
    void extractNetListData(const std::shared_ptr<StepDirectory> &step)
    {
        const auto &CurrNetList = step->GetNetlistsByName();
        if (CurrNetList.empty())
        {
            std::cout << "No Netlist found in the file" << std::endl;
            return;
        }
        else
        {
            std::cout << "\n  [Netlist Data] for Step: " << step->GetName() << std::endl;
            for (const auto &[netlistName, netlistFile] : CurrNetList)
            {
                std::cout << "    Netlist Name: " << netlistName << std::endl;
                std::cout << "    Netlist Name: " << netlistFile->GetName() << std::endl;
                std::cout << "    Netlist File Path: " << netlistFile->GetPath() << std::endl;
                std::cout << " Units: " << netlistFile->GetUnits() << std::endl;
                std::cout << " Optimized: " << (netlistFile->GetOptimized() ? "Yes" : "No") << std::endl;
                std::string staggeredStatus;
                if (netlistFile->GetStaggered() == NetlistFile::Staggered::Yes)
                {
                    staggeredStatus = "Yes";
                }
                else if (netlistFile->GetStaggered() == NetlistFile::Staggered::No)
                {
                    staggeredStatus = "No";
                }
                else
                {
                    staggeredStatus = "Unknown";
                }
                std::cout << "    Staggered: " << staggeredStatus << std::endl;
                // print net records
                const auto &netRecords = netlistFile->GetNetRecords();
                std::cout << " Net Records: " << netRecords.size() << std::endl;
                for (const auto &netRecord : netRecords)
                {
                    std::cout << "    serial number: " << netRecord->serialNumber << std::endl;
                    std::cout << "    net name: " << netRecord->netName << std::endl;
                }
                // print Net Point Records
                const auto &netPointRecords = netlistFile->GetNetPointRecords();
                std::cout << " Net Point Records: " << netPointRecords.size() << std::endl;
                for (const auto &netPointRecord : netPointRecords)
                {
                    std::cout << "    - Net Number: " << netPointRecord->netNumber << std::endl;
                    std::cout << "      Position: (" << netPointRecord->x << ", " << netPointRecord->y << ")" << std::endl;
                    std::cout << "      Radius: " << netPointRecord->radius << std::endl;
                    std::cout << "      Width: " << netPointRecord->width << std::endl;
                    std::cout << "      Height: " << netPointRecord->height << std::endl;
                    std::string side;
                    if (netPointRecord->side == NetlistFile::NetPointRecord::Top)
                    {
                        side = "Top";
                    }
                    else if (netPointRecord->side == NetlistFile::NetPointRecord::Down)
                    {
                        side = "Down";
                    }
                    else if (netPointRecord->side == NetlistFile::NetPointRecord::Both)
                    {
                        side = "Both";
                    }
                    else
                    {
                        side = "Inner";
                    }

                    std::cout << "      Side: " << side << std::endl;
                    std::cout << "    exp: " << netPointRecord->exp << std::endl; // To-Do : if it is NULL then assign 0
                    std::cout << "    commentPoint:   " << netPointRecord->commentPoint << std::endl;
                    std::cout << "    staggeredX: " << netPointRecord->staggeredX << std::endl;
                    std::cout << "    staggeredY:  " << netPointRecord->staggeredY << std::endl;
                    std::cout << "    staggeredRadius: " << netPointRecord->staggeredRadius << std::endl;
                    std::cout << "    viaPoint:   " << netPointRecord->viaPoint << std::endl;
                    std::cout << "    fiducialPoint: " << netPointRecord->fiducialPoint << std::endl;
                    std::cout << "    testPoint: " << netPointRecord->testPoint << std::endl;
                    std::cout << "    testExecutionSide: " << netPointRecord->testExecutionSide << std::endl; // To-Do : if it is NULL then assign 0
                }
            }
        }
    }
}