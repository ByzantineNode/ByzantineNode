#include "extractAttrListFileFromStep.h"
#include "AttrListFile.h"
#include <iostream>

namespace Odb::Lib::FileModel::Design
{

    void extractAttrListFileFromStep(const std::shared_ptr<StepDirectory> &step)
    {
        // Retrieving the AttrListFile object from the StepDirectory
        const auto &CurrAttrListFile = step->GetAttrListFile();

        if (!CurrAttrListFile.GetUnits().empty() || !CurrAttrListFile.GetAttributes().empty())
        {
            std::cout << "///////Attribute List File Information/////////" << std::endl;
            std::cout << "Units: " << CurrAttrListFile.GetUnits() << std::endl;

            // Print attributes
            std::cout << "\nAttributes:" << std::endl;
            for (const auto &kv : CurrAttrListFile.GetAttributes())
            {
                std::cout << " - " << kv.first << " = " << kv.second << std::endl;
            }
            std::cout << "=====================================" << std::endl;
        }
        else
        {
            std::cout << "Attribute List File is empty or not loaded." << std::endl;
        }
    }

} // namespace Odb::Lib::FileModel::Design
