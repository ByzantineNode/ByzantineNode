// extractStepHdrFileData.cpp
#include "extractStepHdrFile.h"
#include "StepDirectory.h"
#include <iostream>
#include "StepHdrFile.h"

namespace Odb::Lib::FileModel::Design
{
    void extractStepHdrFileData(const std::shared_ptr<StepDirectory> &step)
    {
        std::cout << "\n[StepHdr File Data]" << std::endl;

        // Retrieve the StepHdrFile object
        const StepHdrFile &hdr = step->GetStepHdrFile();

        // Print basic fields (assuming they are accessible or have getters)
        std::cout << "xDatum: " << hdr.GetXDatum() << std::endl;
        std::cout << "yDatum: " << hdr.GetYDatum() << std::endl;
        std::cout << "ID: " << hdr.GetId() << std::endl;
        std::cout << "xOrigin: " << hdr.GetXOrigin() << std::endl;
        std::cout << "yOrigin: " << hdr.GetYOrigin() << std::endl;
        std::cout << "Top Active: " << hdr.GetTopActive() << std::endl;
        std::cout << "Bottom Active: " << hdr.GetBottomActive() << std::endl;
        std::cout << "Left Active: " << hdr.GetLeftActive() << std::endl;
        std::cout << "Right Active: " << hdr.GetRightActive() << std::endl;
        std::cout << "Affecting BOM: " << hdr.GetAffectingBom() << std::endl;
        std::cout << "Affecting BOM Changed: " << hdr.GetAffectingBomChanged() << std::endl;

        // Print online values (if a getter is available)
        const auto &onlineValues = hdr.GetOnlineValues();
        if (!onlineValues.empty())
        {
            std::cout << "Online Values:" << std::endl;
            for (const auto &kv : onlineValues)
            {
                std::cout << "  " << kv.first << " = " << kv.second << std::endl;
            }
        }

        // Print Step Repeat Records
        const auto &stepRepeatRecords = hdr.GetStepRepeatRecords();
        std::cout << "Step Repeat Records (" << stepRepeatRecords.size() << "):" << std::endl;
        for (size_t i = 0; i < stepRepeatRecords.size(); ++i)
        {
            const auto &record = stepRepeatRecords[i];
            std::cout << "  Record " << i << ":" << std::endl;
            std::cout << "    Name: " << record->name << std::endl;
            std::cout << "    x: " << record->x << std::endl;
            std::cout << "    y: " << record->y << std::endl;
            std::cout << "    dx: " << record->dx << std::endl;
            std::cout << "    dy: " << record->dy << std::endl;
            std::cout << "    nx: " << record->nx << std::endl;
            std::cout << "    ny: " << record->ny << std::endl;
            std::cout << "    Angle: " << record->angle << std::endl;
            std::cout << "    Flip: " << (record->flip ? "Yes" : "No") << std::endl;
            std::cout << "    Mirror: " << (record->mirror ? "Yes" : "No") << std::endl;
        }
    }
}
