#pragma once
#include "FileArchive.h" // Adjust include if needed

namespace Odb::Lib::FileModel::Design
{
    void extractSymbolsDirectoriesData(const FileArchive &archive);
}
