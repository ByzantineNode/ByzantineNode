#pragma once

#include "StepDirectory.h"

namespace Odb::Lib::FileModel::Design
{
    // Extracts and prints Netlist data for a given step.
    void extractNetListData(const std::shared_ptr<StepDirectory> &step);
}
