#pragma once

#include "StepDirectory.h"

namespace Odb::Lib::FileModel::Design
{
    // Extracts and prints EDA data for a given step.
    void extractStepHdrFileData(const std::shared_ptr<StepDirectory> &step);
}
