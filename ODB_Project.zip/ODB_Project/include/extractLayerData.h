// extractLayerData.h
#pragma once

#include "StepDirectory.h" // For std::shared_ptr<StepDirectory>

namespace Odb::Lib::FileModel::Design
{

    // Iterates over all layers in the given step and processes each one.
    void extractLayerData(const std::shared_ptr<StepDirectory> &step);

} // namespace Odb::Lib::FileModel::Design
