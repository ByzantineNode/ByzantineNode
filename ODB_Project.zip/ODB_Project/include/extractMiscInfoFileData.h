// extractStepData.h
#pragma once

#include "FileArchive.h"

namespace Odb::Lib::FileModel::Design
{

    // Iterates over all steps in the archive and processes each step.
    void extractMiscInfoFileData(const FileArchive &archive);

} // namespace Odb::Lib::FileModel::Design
