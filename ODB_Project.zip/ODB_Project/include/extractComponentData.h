#pragma once

#include "FileArchive.h"

namespace Odb::Lib::FileModel::Design {
    // Function declaration
    void extractComponentData(const FileArchive &archive);
}