#pragma once

#include "LayerDirectory.h"

namespace Odb::Lib::FileModel::Design
{

    // Extracts and prints feature data for a single layer.
    void extractAttributeDataFromLayer(const std::shared_ptr<LayerDirectory> &layer);

} // namespace Odb::Lib::FileModel::Design
